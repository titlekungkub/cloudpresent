from __future__ import print_function

import boto3
import io
from decimal import Decimal
import json
import urllib
import time
import numpy as np
import base64

import cv2

rekognition = boto3.client('rekognition')
s3 = boto3.client('s3')


# --------------- Helper Functions to call Rekognition APIs ------------------


def detect_faces(bucket, key):
    response = rekognition.detect_faces(Image={"S3Object": {"Bucket": bucket, "Name": key}})
    return response

def search_face(bucket, key, collection, boxwidth, boxheight, boxleft, boxtop):
    
    s3_connection = boto3.resource('s3')
    s3_object = s3_connection.Object(bucket,key)
    s3_response = s3_object.get()

    stream = io.BytesIO(s3_response['Body'].read())
    
    img = cv2.imdecode(np.fromstring(stream.read(), np.uint8), 1)

    imgheight, imgwidth, imgchannels = img.shape
    
    cropped = img[boxtop*imgheight:boxtop*imgheight+boxheight*imgheight, boxleft*imgwidth:boxleft*imgwidth+boxwidth*imgwidth]
    
    response = rekognition.search_faces_by_image(
    CollectionId=collection,
    Image={"Bytes": cv2.imencode('.jpg', cropped)[1].tostring()},
    MaxFaces=1
    )
    return response


# --------------- Main handler ------------------


def lambda_handler(event, context):

    #print("Received event: " + json.dumps(event, indent=2))

    encodedImg = json.loads(event['body'])['image_data'].split('base64,')[1]
    decodedImg = base64.b64decode(encodedImg)

    bucket = 'presentproject'
    key = '2018/2/2110498/attendance/' + time.strftime('%Y-%m-%d') + '.jpg'
    
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=decodedImg
    )

    list_of_students = []
    
    folder = key.split('/attendance')[0] # collection in format '2018/2/2110498'
    collection = folder.replace('/','-')
    print(collection)
    
    try:
        # Calls rekognition DetectFaces API to detect faces in S3 object
        faces = detect_faces(bucket, key)
        
        for face in faces['FaceDetails']:
            print(face)
            # Calls rekognition SearchFaceByImage
            searchResponse = search_face(bucket, key, collection, face['BoundingBox']['Width'], face['BoundingBox']['Height'], face['BoundingBox']['Left'], face['BoundingBox']['Top'])
            print(searchResponse)
            if(searchResponse['FaceMatches']):
                id =  searchResponse['FaceMatches'][0]['Face']['ExternalImageId']
                list_of_students.append(id)
                print(id)

        print('Done.')
        print(list_of_students)

        s3.put_object(
            Bucket='presentproject',
            Key=folder+'/result/' + time.strftime('%Y-%m-%d') + '.csv',
            Body='\n'.join(list_of_students)
        )

        response = {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps(list_of_students)
        }

        return response

    except Exception as e:
        print(e)

        
        response = {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'}
        }

        return response
        
        raise e
